--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "F1_22";
--
-- Name: F1_22; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "F1_22" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Chile.1252';


ALTER DATABASE "F1_22" OWNER TO postgres;

\connect "F1_22"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: engine_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_supplier (
    supplier_id integer NOT NULL,
    supplier_name text NOT NULL,
    supplier_country text,
    supplier_engine_spec text,
    supplier_acronym text
);


ALTER TABLE public.engine_supplier OWNER TO postgres;

--
-- Name: engine_supplier_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.engine_supplier_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.engine_supplier_supplier_id_seq OWNER TO postgres;

--
-- Name: engine_supplier_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.engine_supplier_supplier_id_seq OWNED BY public.engine_supplier.supplier_id;


--
-- Name: f1_constructor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.f1_constructor (
    team_id integer NOT NULL,
    team_name text NOT NULL,
    team_full_name text,
    team_chassis text,
    team_country text,
    team_engine text
);


ALTER TABLE public.f1_constructor OWNER TO postgres;

--
-- Name: f1_constructor_team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.f1_constructor_team_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.f1_constructor_team_id_seq OWNER TO postgres;

--
-- Name: f1_constructor_team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.f1_constructor_team_id_seq OWNED BY public.f1_constructor.team_id;


--
-- Name: f1_countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.f1_countries (
    country_id integer NOT NULL,
    country_name text NOT NULL,
    country_three_letters text,
    country_continent text
);


ALTER TABLE public.f1_countries OWNER TO postgres;

--
-- Name: f1_countries_country_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.f1_countries_country_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.f1_countries_country_id_seq OWNER TO postgres;

--
-- Name: f1_countries_country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.f1_countries_country_id_seq OWNED BY public.f1_countries.country_id;


--
-- Name: f1_drivers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.f1_drivers (
    driver_id integer NOT NULL,
    driver_number integer,
    driver_name text NOT NULL,
    driver_img_url text,
    driver_country text,
    driver_team text
);


ALTER TABLE public.f1_drivers OWNER TO postgres;

--
-- Name: f1_drivers_driver_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.f1_drivers_driver_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.f1_drivers_driver_id_seq OWNER TO postgres;

--
-- Name: f1_drivers_driver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.f1_drivers_driver_id_seq OWNED BY public.f1_drivers.driver_id;


--
-- Name: f1_tracks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.f1_tracks (
    track_id integer NOT NULL,
    track_name text NOT NULL,
    track_alt_name text,
    track_city text,
    track_country text
);


ALTER TABLE public.f1_tracks OWNER TO postgres;

--
-- Name: f1_tracks_track_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.f1_tracks_track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.f1_tracks_track_id_seq OWNER TO postgres;

--
-- Name: f1_tracks_track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.f1_tracks_track_id_seq OWNED BY public.f1_tracks.track_id;


--
-- Name: gp_points_system; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gp_points_system (
    gp_position integer NOT NULL,
    gp_points_awarded integer
);


ALTER TABLE public.gp_points_system OWNER TO postgres;

--
-- Name: grand_prix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grand_prix (
    gp_id integer NOT NULL,
    gp_round integer,
    gp_name text NOT NULL,
    gp_full_name text,
    gp_country text,
    gp_date date,
    gp_laps integer,
    gp_weather text,
    gp_track text,
    gp_poleman text,
    gp_pole_time time without time zone,
    gp_fastest_lap_achiever text,
    gp_fastest_lap time without time zone
);


ALTER TABLE public.grand_prix OWNER TO postgres;

--
-- Name: grand_prix_gp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grand_prix_gp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grand_prix_gp_id_seq OWNER TO postgres;

--
-- Name: grand_prix_gp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grand_prix_gp_id_seq OWNED BY public.grand_prix.gp_id;


--
-- Name: results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.results (
    gp_round integer NOT NULL,
    driver_name text NOT NULL,
    gp_position integer,
    gp_status text
);


ALTER TABLE public.results OWNER TO postgres;

--
-- Name: sprint_points_system; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sprint_points_system (
    sp_position integer NOT NULL,
    sp_points_awarded integer
);


ALTER TABLE public.sprint_points_system OWNER TO postgres;

--
-- Name: sprint_race; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sprint_race (
    sprint_round integer NOT NULL,
    sprint_track text,
    sprint_laps integer
);


ALTER TABLE public.sprint_race OWNER TO postgres;

--
-- Name: sprint_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sprint_results (
    sp_round integer NOT NULL,
    sp_driver text NOT NULL,
    sp_position integer,
    sp_status text
);


ALTER TABLE public.sprint_results OWNER TO postgres;

--
-- Name: engine_supplier supplier_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_supplier ALTER COLUMN supplier_id SET DEFAULT nextval('public.engine_supplier_supplier_id_seq'::regclass);


--
-- Name: f1_constructor team_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_constructor ALTER COLUMN team_id SET DEFAULT nextval('public.f1_constructor_team_id_seq'::regclass);


--
-- Name: f1_countries country_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_countries ALTER COLUMN country_id SET DEFAULT nextval('public.f1_countries_country_id_seq'::regclass);


--
-- Name: f1_drivers driver_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_drivers ALTER COLUMN driver_id SET DEFAULT nextval('public.f1_drivers_driver_id_seq'::regclass);


--
-- Name: f1_tracks track_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_tracks ALTER COLUMN track_id SET DEFAULT nextval('public.f1_tracks_track_id_seq'::regclass);


--
-- Name: grand_prix gp_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix ALTER COLUMN gp_id SET DEFAULT nextval('public.grand_prix_gp_id_seq'::regclass);


--
-- Data for Name: engine_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.engine_supplier (supplier_id, supplier_name, supplier_country, supplier_engine_spec, supplier_acronym) FROM stdin;
\.
COPY public.engine_supplier (supplier_id, supplier_name, supplier_country, supplier_engine_spec, supplier_acronym) FROM '$$PATH$$/4939.dat';

--
-- Data for Name: f1_constructor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.f1_constructor (team_id, team_name, team_full_name, team_chassis, team_country, team_engine) FROM stdin;
\.
COPY public.f1_constructor (team_id, team_name, team_full_name, team_chassis, team_country, team_engine) FROM '$$PATH$$/4941.dat';

--
-- Data for Name: f1_countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.f1_countries (country_id, country_name, country_three_letters, country_continent) FROM stdin;
\.
COPY public.f1_countries (country_id, country_name, country_three_letters, country_continent) FROM '$$PATH$$/4937.dat';

--
-- Data for Name: f1_drivers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.f1_drivers (driver_id, driver_number, driver_name, driver_img_url, driver_country, driver_team) FROM stdin;
\.
COPY public.f1_drivers (driver_id, driver_number, driver_name, driver_img_url, driver_country, driver_team) FROM '$$PATH$$/4943.dat';

--
-- Data for Name: f1_tracks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.f1_tracks (track_id, track_name, track_alt_name, track_city, track_country) FROM stdin;
\.
COPY public.f1_tracks (track_id, track_name, track_alt_name, track_city, track_country) FROM '$$PATH$$/4945.dat';

--
-- Data for Name: gp_points_system; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gp_points_system (gp_position, gp_points_awarded) FROM stdin;
\.
COPY public.gp_points_system (gp_position, gp_points_awarded) FROM '$$PATH$$/4951.dat';

--
-- Data for Name: grand_prix; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grand_prix (gp_id, gp_round, gp_name, gp_full_name, gp_country, gp_date, gp_laps, gp_weather, gp_track, gp_poleman, gp_pole_time, gp_fastest_lap_achiever, gp_fastest_lap) FROM stdin;
\.
COPY public.grand_prix (gp_id, gp_round, gp_name, gp_full_name, gp_country, gp_date, gp_laps, gp_weather, gp_track, gp_poleman, gp_pole_time, gp_fastest_lap_achiever, gp_fastest_lap) FROM '$$PATH$$/4947.dat';

--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.results (gp_round, driver_name, gp_position, gp_status) FROM stdin;
\.
COPY public.results (gp_round, driver_name, gp_position, gp_status) FROM '$$PATH$$/4952.dat';

--
-- Data for Name: sprint_points_system; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sprint_points_system (sp_position, sp_points_awarded) FROM stdin;
\.
COPY public.sprint_points_system (sp_position, sp_points_awarded) FROM '$$PATH$$/4949.dat';

--
-- Data for Name: sprint_race; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sprint_race (sprint_round, sprint_track, sprint_laps) FROM stdin;
\.
COPY public.sprint_race (sprint_round, sprint_track, sprint_laps) FROM '$$PATH$$/4948.dat';

--
-- Data for Name: sprint_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sprint_results (sp_round, sp_driver, sp_position, sp_status) FROM stdin;
\.
COPY public.sprint_results (sp_round, sp_driver, sp_position, sp_status) FROM '$$PATH$$/4950.dat';

--
-- Name: engine_supplier_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.engine_supplier_supplier_id_seq', 4, true);


--
-- Name: f1_constructor_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.f1_constructor_team_id_seq', 10, true);


--
-- Name: f1_countries_country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.f1_countries_country_id_seq', 29, true);


--
-- Name: f1_drivers_driver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.f1_drivers_driver_id_seq', 44, true);


--
-- Name: f1_tracks_track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.f1_tracks_track_id_seq', 22, true);


--
-- Name: grand_prix_gp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grand_prix_gp_id_seq', 44, true);


--
-- Name: f1_countries country_name_unq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_countries
    ADD CONSTRAINT country_name_unq UNIQUE (country_name);


--
-- Name: engine_supplier engine_supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_supplier
    ADD CONSTRAINT engine_supplier_pkey PRIMARY KEY (supplier_id, supplier_name);


--
-- Name: engine_supplier engine_supplier_supplier_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_supplier
    ADD CONSTRAINT engine_supplier_supplier_name_key UNIQUE (supplier_name);


--
-- Name: f1_constructor f1_constructor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_constructor
    ADD CONSTRAINT f1_constructor_pkey PRIMARY KEY (team_id, team_name);


--
-- Name: f1_constructor f1_constructor_team_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_constructor
    ADD CONSTRAINT f1_constructor_team_name_key UNIQUE (team_name);


--
-- Name: f1_countries f1_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_countries
    ADD CONSTRAINT f1_countries_pkey PRIMARY KEY (country_id, country_name);


--
-- Name: f1_drivers f1_drivers_driver_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_drivers
    ADD CONSTRAINT f1_drivers_driver_name_key UNIQUE (driver_name);


--
-- Name: f1_drivers f1_drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_drivers
    ADD CONSTRAINT f1_drivers_pkey PRIMARY KEY (driver_id, driver_name);


--
-- Name: f1_tracks f1_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_tracks
    ADD CONSTRAINT f1_tracks_pkey PRIMARY KEY (track_id, track_name);


--
-- Name: f1_tracks f1_tracks_track_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_tracks
    ADD CONSTRAINT f1_tracks_track_name_key UNIQUE (track_name);


--
-- Name: gp_points_system gp_points_system_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gp_points_system
    ADD CONSTRAINT gp_points_system_pkey PRIMARY KEY (gp_position);


--
-- Name: grand_prix gp_round_unq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT gp_round_unq UNIQUE (gp_round);


--
-- Name: grand_prix grand_prix_gp_full_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_gp_full_name_key UNIQUE (gp_full_name);


--
-- Name: grand_prix grand_prix_gp_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_gp_name_key UNIQUE (gp_name);


--
-- Name: grand_prix grand_prix_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_pkey PRIMARY KEY (gp_id, gp_name);


--
-- Name: results results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (gp_round, driver_name);


--
-- Name: sprint_points_system sprint_points_system_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_points_system
    ADD CONSTRAINT sprint_points_system_pkey PRIMARY KEY (sp_position);


--
-- Name: sprint_race sprint_race_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_race
    ADD CONSTRAINT sprint_race_pkey PRIMARY KEY (sprint_round);


--
-- Name: sprint_results sprint_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_results
    ADD CONSTRAINT sprint_results_pkey PRIMARY KEY (sp_round, sp_driver);


--
-- Name: engine_supplier engine_supplier_supplier_country_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_supplier
    ADD CONSTRAINT engine_supplier_supplier_country_fkey FOREIGN KEY (supplier_country) REFERENCES public.f1_countries(country_name);


--
-- Name: f1_constructor f1_constructor_team_country_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_constructor
    ADD CONSTRAINT f1_constructor_team_country_fkey FOREIGN KEY (team_country) REFERENCES public.f1_countries(country_name);


--
-- Name: f1_constructor f1_constructor_team_engine_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_constructor
    ADD CONSTRAINT f1_constructor_team_engine_fkey FOREIGN KEY (team_engine) REFERENCES public.engine_supplier(supplier_name);


--
-- Name: f1_drivers f1_drivers_driver_team_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_drivers
    ADD CONSTRAINT f1_drivers_driver_team_fkey FOREIGN KEY (driver_team) REFERENCES public.f1_constructor(team_name);


--
-- Name: f1_tracks f1_tracks_track_country_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.f1_tracks
    ADD CONSTRAINT f1_tracks_track_country_fkey FOREIGN KEY (track_country) REFERENCES public.f1_countries(country_name);


--
-- Name: grand_prix grand_prix_gp_country_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_gp_country_fkey FOREIGN KEY (gp_country) REFERENCES public.f1_countries(country_name);


--
-- Name: grand_prix grand_prix_gp_fastest_lap_achiever_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_gp_fastest_lap_achiever_fkey FOREIGN KEY (gp_fastest_lap_achiever) REFERENCES public.f1_drivers(driver_name);


--
-- Name: grand_prix grand_prix_gp_poleman_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_gp_poleman_fkey FOREIGN KEY (gp_poleman) REFERENCES public.f1_drivers(driver_name);


--
-- Name: grand_prix grand_prix_gp_track_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grand_prix
    ADD CONSTRAINT grand_prix_gp_track_fkey FOREIGN KEY (gp_track) REFERENCES public.f1_tracks(track_name);


--
-- Name: results results_driver_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_driver_name_fkey FOREIGN KEY (driver_name) REFERENCES public.f1_drivers(driver_name);


--
-- Name: results results_gp_position_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_gp_position_fkey FOREIGN KEY (gp_position) REFERENCES public.gp_points_system(gp_position);


--
-- Name: results results_gp_round_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_gp_round_fkey FOREIGN KEY (gp_round) REFERENCES public.grand_prix(gp_round);


--
-- Name: sprint_race sprint_race_sprint_track_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_race
    ADD CONSTRAINT sprint_race_sprint_track_fkey FOREIGN KEY (sprint_track) REFERENCES public.f1_tracks(track_name);


--
-- Name: sprint_results sprint_results_sp_driver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_results
    ADD CONSTRAINT sprint_results_sp_driver_fkey FOREIGN KEY (sp_driver) REFERENCES public.f1_drivers(driver_name);


--
-- Name: sprint_results sprint_results_sp_position_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_results
    ADD CONSTRAINT sprint_results_sp_position_fkey FOREIGN KEY (sp_position) REFERENCES public.sprint_points_system(sp_position);


--
-- Name: sprint_results sprint_results_sp_round_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint_results
    ADD CONSTRAINT sprint_results_sp_round_fkey FOREIGN KEY (sp_round) REFERENCES public.sprint_race(sprint_round);


--
-- PostgreSQL database dump complete
--

